declare module 'react-native-vector-icons/*' {
  import { Icon } from 'react-native-vector-icons/Icon';
  export default Icon;
}
